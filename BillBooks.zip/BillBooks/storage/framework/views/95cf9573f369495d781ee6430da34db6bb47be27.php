<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a class="btn btn-default btn-new-author" data-toggle="modal" data-target="#primaryModal">Add Author</a>
                    <a class="btn btn-default btn-new-book" data-toggle="modal" data-target="#primaryModal">Add Book</a>
                </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    
                    <h4>Authors List</h4>
                    <?php if(!$authors->isEmpty()): ?>
                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            <div class="col-md-4 col-xs-12 col-sm-6">
                                <div class="">
                                    <?php echo $__env->make('author.partial.widget', $author, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            </div>       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    <?php else: ?>
                        <div class="col-md-12 col-xs-12 col-sm-12">
                            <div class="">
                                Nope, you don't have any authors yet.
                            </div>
                        </div>
                    <?php endif; ?>      
                </div>
                <div class="panel-body">
                    <h4>Books List</h4>   
                    <?php if(!$books->isEmpty()): ?>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            <div class="col-md-4 col-xs-12 col-sm-6">
                                <div class="">
                                    <?php echo $__env->make('book.partial.widget', $book, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            </div>       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    <?php else: ?>
                        <div class="col-md-12 col-xs-12 col-sm-12">
                            <div class="">
                                 Nope, you don't have any books yet.
                            </div>
                        </div>
                    <?php endif; ?>      
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>