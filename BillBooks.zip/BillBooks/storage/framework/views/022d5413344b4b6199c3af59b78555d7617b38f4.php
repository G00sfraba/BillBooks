<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
    <label for="title" class="col-md-4 col-xs-12 col-sm-4 control-label">Book title:</label>

    <div class="col-md-8 col-sm-8 col-xs-12">
        <input id="title" type="text" class="form-control" name="title" value="<?php echo e($book->title ?? old('title')); ?>" required autofocus>

        <?php if($errors->has('title')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('title')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group<?php echo e($errors->has('author_id') ? ' has-error' : ''); ?>">
    <label for="author_id" class="col-md-4 col-xs-12 col-sm-4 control-label">Select Author</label>

    <div class="col-md-8 col-sm-8 col-xs-12">
        <select id="author_id" name="author_id" value="<?php echo e($book->author_id ?? old('author_id')); ?>" class="form-control">                       
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($author->id); ?>" <?php if(old('author_id') == $author->id || (isset($book) && $book->author_id == $author->id)): ?> selected="selected" <?php endif; ?>><?php echo e($author->name); ?></option>                       
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
        </select>

        <?php if($errors->has('author_id')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('author_id')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group<?php echo e($errors->has('purchased') ? ' has-error' : ''); ?>">
    <label for="purchased" class="col-md-4 col-xs-12 col-sm-4 control-label">Year of purchase</label>

    <div class="col-md-8 col-sm-8 col-xs-12">
        <input id="purchased" type="number" class="form-control" name="purchased" value="<?php echo e($book->purchased ?? old('purchased')); ?>" required >

        <?php if($errors->has('purchased')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('purchased')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group<?php echo e($errors->has('cover') ? ' has-error' : ''); ?>">
    <label for="cover" class="col-md-4 col-xs-12 col-sm-4 control-label">Cover</label>

    <div class="col-md-8 col-sm-8 col-xs-12">
        <input id="cover" type="file" class="form-control" name="cover" required >

        <?php if($errors->has('cover')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('cover')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group<?php echo e($errors->has('notes') ? ' has-error' : ''); ?>">
    <label for="notes" class="col-md-4 col-xs-12 col-sm-4 control-label">Notes</label>

    <div class="col-md-8 col-sm-8 col-xs-12">
        <input id="notes" type="text" class="form-control" name="notes" value="<?php echo e($book->notes ?? old('notes')); ?>">

        <?php if($errors->has('notes')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('notes')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>

