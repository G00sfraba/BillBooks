<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="name" class="col-md-4 col-xs-12 col-sm-4 control-label">Author name:</label>

    <div class="col-md-8 col-sm-8 col-xs-12">
        <input id="name" type="text" class="form-control" name="name" value="<?php echo e($author->name ?? old('name')); ?>" required autofocus>

        <?php if($errors->has('name')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('name')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>


<div class="form-group<?php echo e($errors->has('notes') ? ' has-error' : ''); ?>">
    <label for="notes" class="col-md-4 col-xs-12 col-sm-4 control-label">Notes</label>

    <div class="col-md-8 col-sm-8 col-xs-12">
        <input id="notes" type="text" class="form-control" name="notes" value="<?php echo e($author->notes ?? old('notes')); ?>" required >

        <?php if($errors->has('notes')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('notes')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>
