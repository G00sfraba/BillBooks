<div class="col-md-12 text-center widget">
    <div class="widget-btns">
        <a href="/author/<?php echo e($author->id); ?>/" class="btn-author-books">
            <i class="fa fa-book" 
               aria-hidden="true" 
               title="Books" 
               data-toggle="popover" 
               data-placement="bottom" 
               data-trigger="hover" 
               data-content="Open your books collection from <?php echo e($author->name); ?>"> <?php echo e(App\Book::authorBooksCount($author->id)); ?></i>
        </a>
        <a class="btn-edit-author" author='<?php echo e($author->id); ?>' data-toggle="modal" data-target="#primaryModal">
            <i class="fa fa-pencil"  
               aria-hidden="true" title="Edit" 
               data-toggle="popover" 
               data-placement="bottom" 
               data-trigger="hover" 
               data-content="Edit the infromation about <?php echo e($author->name); ?>"></i>
        </a>
        <a class="btn-delete-author" author='<?php echo e($author->id); ?>' data-toggle="modal" data-target="#primaryModal">
            <i class="fa fa-trash-o"  
               aria-hidden="true" 
               title="Delete" 
               data-toggle="popover" 
               data-placement="bottom" 
               data-trigger="hover" 
               data-content="Delete this author and all of the books associated with <?php echo e($author->name); ?>"></i>
        </a>
        <div class="clearfix"></div>
    </div>
    <h3><?php echo e($author->name); ?></h3>
    <div class="notes" 
         title="Notes" 
         data-toggle="popover" 
         data-placement="top" 
         data-trigger="hover" 
         data-content="<?php echo e($author->notes); ?>"><?php echo e($author->notes); ?></div>    

</div>