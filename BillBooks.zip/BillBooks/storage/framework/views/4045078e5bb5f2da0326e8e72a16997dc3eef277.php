<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>

    <h1>Add New Book</h1>
</div>
<div class="modal-body">
    <div class="">

        <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>

        <?php if($authors->isEmpty()): ?>

        <DIV> Please add authors first</DIV>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>            
        </div>

        <?php else: ?>
        <form id="book-modal-form" class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" action="/ajax/book/add-book">
            <?php echo e(csrf_field()); ?>


            <?php echo $__env->make('book.partial.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                <button id="btn-submit" type="button" class="btn btn-success">Save</button>
            </div>
        </form>
        <?php endif; ?>
    </div>
</div>
